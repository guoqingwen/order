if ((navigator.userAgent.match(/(iPhone|iPod|Android|ios|iOS|iPad|Backerry|WebOS|Symbian|Windows Phone|Phone)/i))) { 

}else{
document.write("<script type=\"text/javascript\">google_ad_client = \"ca-pub-7515443544894528\";google_ad_slot = \"3076591508\";google_ad_width = 468;google_ad_height = 60;</script>");
document.write("<script type=\"text/javascript\" src=\"//pagead2.googlesyndication.com/pagead/show_ads.js\"></script>");
}