//760x90
document.write("<script type=\"text/javascript\">google_ad_client = \"ca-pub-7515443544894528\";google_ad_slot = \"3438097725\";google_ad_width = 728;google_ad_height = 90;</script>");
document.write("<script type=\"text/javascript\" src=\"//pagead2.googlesyndication.com/pagead/show_ads.js\"></script>");

//document.write("<script charset=\"gbk\" src=\"http://p.tanx.com/ex?i=mm_31834074_3358239_20016592\"><\/script>");
//浮窗
//document.write("<script charset=\"gbk\" src=\"http://p.tanx.com/ex?i=mm_31834074_3358239_13080436\"></script>");